create TYPE student1 AS OBJECT
(nume varchar2(10),
 prenume varchar2(10),
 grupa varchar2(4),
 an number(1), 
 data_nastere date,
 NOT FINAL member procedure afiseaza_foaie_matricola,
 map member FUNCTION varsta_in_zile RETURN NUMBER, 
 CONSTRUCTOR FUNCTION student1(nume varchar2, prenume varchar2)
    RETURN SELF AS RESULT
) NOT FINAL;
/

