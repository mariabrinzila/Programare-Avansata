create procedure execute_query (select_query in varchar2) as
    v_cursor_id INTEGER;
    v_ok INTEGER;
    v_rec_tab DBMS_SQL.DESC_TAB;
    v_nr_col NUMBER;
    v_total_coloane NUMBER; 
    v_nume_col VARCHAR2(100);
    v_query_res VARCHAR2(100);
    block1 VARCHAR2(4000);
begin
    v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(v_cursor_id , select_query, DBMS_SQL.NATIVE);
    v_ok := DBMS_SQL.EXECUTE(v_cursor_id );
    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);

    v_nr_col := v_rec_tab.first;
    IF (v_nr_col IS NOT NULL) THEN
        LOOP
            --DBMS_OUTPUT.PUT_LINE(v_rec_tab(v_nr_col).col_name);
            v_query_res := 'test';
            block1 := 'BEGIN
                DBMS_OUTPUT.PUT_LINE(''col_name: ' || v_rec_tab(v_nr_col).col_name || ': ' || v_query_res || ''');
                END;';
            EXECUTE IMMEDIATE block1;
            v_nr_col := v_rec_tab.next(v_nr_col);
            EXIT WHEN (v_nr_col IS NULL);
        END LOOP;
    END IF;
    DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
end;
/

