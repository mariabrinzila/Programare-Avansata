create PACKAGE idk AS
    FUNCTION nr_ani (v_id IN NUMBER) RETURN NUMBER;
    PROCEDURE angajat (v_ani IN NUMBER, v_id IN NUMBER);
END idk;
/

