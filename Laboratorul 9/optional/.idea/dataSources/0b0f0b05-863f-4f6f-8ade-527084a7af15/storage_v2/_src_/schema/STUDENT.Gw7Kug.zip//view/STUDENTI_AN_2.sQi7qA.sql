create view STUDENTI_AN_2 as
SELECT nume, prenume, grupa FROM studenti WHERE an = 2
/

