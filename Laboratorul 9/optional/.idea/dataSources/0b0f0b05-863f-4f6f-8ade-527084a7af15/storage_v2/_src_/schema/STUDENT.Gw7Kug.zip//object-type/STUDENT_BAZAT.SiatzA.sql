create TYPE student_bazat UNDER student1
(    
   bursa NUMBER(6,2),
   OVERRIDING member procedure afiseaza_foaie_matricola
)
/

