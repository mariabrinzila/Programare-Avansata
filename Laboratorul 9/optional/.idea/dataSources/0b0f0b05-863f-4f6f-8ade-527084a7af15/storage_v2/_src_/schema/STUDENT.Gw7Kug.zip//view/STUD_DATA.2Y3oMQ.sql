create view STUD_DATA as
SELECT data_nastere, nume FROM studenti
/

