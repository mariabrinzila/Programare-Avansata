create PROCEDURE putere (p_nr IN OUT NUMBER, p_exponent IN INTEGER DEFAULT 2) AS
BEGIN
    IF (p_nr > 10) THEN
        p_nr := p_nr + 1;
    END IF; 
    p_nr := p_nr ** p_exponent;
END;
/

