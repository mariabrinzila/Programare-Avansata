create PACKAGE BODY idk AS
BEGIN
    FUNCTION nr_ani (v_id IN NUMBER)
    RETURN NUMBER IS
        v_ani NUMBER;
    BEGIN
        SELECT (ROUND(MONTHS_BETWEEN(SYSDATE, data_nastere)/12) INTO v_ani FROM cadre_medicale WHERE id = v_id;
        RETURN v_ani;
    END;

    PROCEDURE angajat (v_ani IN NUMBER, v_id IN NUMBER) IS
        v_ani NUMBER;
    BEGIN
        v_ani := nr_ani(v_id);
        SELECT nume INTO v_nume FROM cadre_medicale WHERE id = v_id;
        DBMS_OUTPUT.PUT_LINE(v_nume);
    END;
END idk;
/

