create PACKAGE BODY varsta_pacient IS
    FUNCTION calculeaza (data_nastere DATE) RETURN INT AS
    BEGIN
       RETURN FLOOR((g_today_date - data_nastere) / 365);
    END calculeaza; 
END varsta_pacient;
/

