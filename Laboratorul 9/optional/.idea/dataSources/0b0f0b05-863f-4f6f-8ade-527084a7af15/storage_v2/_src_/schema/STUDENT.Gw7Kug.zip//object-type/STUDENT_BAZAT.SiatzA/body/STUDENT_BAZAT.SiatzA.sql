create TYPE BODY student_bazat AS
    OVERRIDING MEMBER PROCEDURE afiseaza_foaie_matricola IS
    BEGIN
       dbms_output.put_line('bursier');
    END afiseaza_foaie_matricola;
END;
/

