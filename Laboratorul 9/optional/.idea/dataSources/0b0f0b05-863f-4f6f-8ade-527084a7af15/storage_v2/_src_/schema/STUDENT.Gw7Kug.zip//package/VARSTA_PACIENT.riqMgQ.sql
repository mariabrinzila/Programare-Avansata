create PACKAGE varsta_pacient IS
    g_today_date DATE := SYSDATE;
    FUNCTION calculeaza (data_nastere DATE) RETURN INT;
END varsta_pacient;
/

